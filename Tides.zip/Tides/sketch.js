// sketch.js

let tidesImage;

function preload() {
  tidesImage = loadImage("Tides.png");
}

let a = 0

function setup() {
  createCanvas(800, 800);

}

function draw() {
  background(225,246,255);
  imageMode(CENTER);
  image(tidesImage, 400, 550)

  push();
  // Sun & Moon
  let sunAndmoonSize = 60
  let sunAndmoonY = 100
  let sunAndmoonX = hour() * 33;
  translate(sunAndmoonX, sunAndmoonY);
  stroke(255,200,0);
  strokeWeight(2);
  if (hour() < 7 || hour() > 19) {
    fill (255,255,255)
  }
  else {
    fill (255,255,0);
  }

  //Movement
  a = a + (TWO_PI /60);
  rotate(a)

  ellipse(0, 0, sunAndmoonSize, sunAndmoonSize);
  
  //Line
  stroke(255,200,0);
  strokeWeight(2);
  line(0, -sunAndmoonSize / 2, 0, sunAndmoonSize / 2);
  pop();

  textSize(15);
  text('High Tide', 430,440)
  
  textSize(15);
  text('High Tide', 0,360)

  textSize(15);
  text('Low Tide', 290,590)
}






